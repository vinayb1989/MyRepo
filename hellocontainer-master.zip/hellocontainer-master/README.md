Sample application packaged as a container
